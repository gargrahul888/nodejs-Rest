const mongoose = require('mongoose')

const connectionString = 'mongodb://localhost:27017/api_db';

mongoose.connect(connectionString, { useNewUrlParser: true })
const db = mongoose.connection
db.once('open', _ => {
    console.log('Database connected:', connectionString)
})

db.on('error', err => {
    console.error('connection error:', err)
})