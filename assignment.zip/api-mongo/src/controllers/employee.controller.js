const employeeModel = require('../models/employee.model');

exports.getEmployeeList = async (req, res) => {
    // console.log(req);
    //
    try {
        const results = await employeeModel.find();
        res.status(200).json(
            {
                success: true,
                data: results,
                message: 'Employee List!'
            }
        );
    } catch (error) {
        res.status(500).json(
            {
                success: false,
                data: error
            }
        );
    }
};

exports.createNewEmployee = async (req, res) => {

    try {
        const email = req.body.email;
        const rows = await employeeModel.findOne({ email });
        if (rows) {
            return res.status(403).json({ message: 'This email is already registered', success: false });
        }

        // Create a Note
        const emplyeeReqData = new employeeModel({
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            phone: req.body.phone,
            designation: req.body.designation,
            salary: req.body.salary,
            status: 1,
            is_deleted: 0,
        });

        const result = await emplyeeReqData.save(emplyeeReqData);
        res.status(200).json(
            {
                success: true,
                data: result,
                message: 'Employee added successfully!'
            }
        );
    } catch (error) {
        res.status(500).json(
            {
                success: false,
                data: error
            }
        );
    }

}
