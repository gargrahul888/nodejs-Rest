const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employee.controller');
const validationMiddleware = require('../middleware/employee-validation');

// route for get list of employees
router.get('/', employeeController.getEmployeeList);
// get employee by id

// add employee
router.post('/', validationMiddleware.createEmployee, employeeController.createNewEmployee);

module.exports = router;

