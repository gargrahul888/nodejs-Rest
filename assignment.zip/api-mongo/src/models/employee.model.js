const dbconn = require('../../config/db.config');

const mongoose = require('mongoose');

const EmployeeSchema = mongoose.Schema({
    first_name: String,
    last_name: String,
    email: String,
    phone: String,
    designation: String,
    salary: Number,
    status: Boolean,
    is_deleted: Boolean
}, {
    timestamps: true
});

module.exports = mongoose.model('Employee', EmployeeSchema);