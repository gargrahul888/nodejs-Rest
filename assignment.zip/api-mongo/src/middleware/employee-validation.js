
const validator = require('../helpers/validate');

const createEmployee = (req, res, next) => {
    const validationRule = {
        "first_name": "required|string|min:3",
        "last_name": "required|string|min:3",
        "organization": "required|string|min:3",
        "designation": "required|string|min:3",
        "email": "required|email",
        "phone": "required|regex:/^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/",
        "salary": "required|numeric",
        "gender": "string"
    }
    validator(req.body, validationRule, {}, (err, status) => {
        if (!status) {
            res.status(412)
                .send({
                    success: false,
                    message: 'Validation failed',
                    data: err
                });
        } else {
            next();
        }
    });
}

module.exports = {
    createEmployee
}