const mysql = require('mysql');

const dbconn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'api_db'
});

dbconn.connect((err) => {
    if (err) throw err;

    console.log("database connected");
});

module.exports = dbconn;

