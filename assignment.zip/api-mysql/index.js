
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require("helmet");
// creat express app
const app = express();
app.use(helmet());

app.use(bodyParser.json());
app.use(cors());
app.use(
    bodyParser.urlencoded({
        extended: false,
    })
);

const dotenv = require('dotenv');
dotenv.config();

//define the root route for server
app.get('/', (req, res) => {
    res.json({ 'message': 'ok' });
})

// import employee routes from
const employeeRoute = require('./src/routes/employee.route');


app.use('/api/v1/employee', employeeRoute);

//listen the port 
///setup the port number
const port = process.env.PORT || 5000;
app.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`)
});