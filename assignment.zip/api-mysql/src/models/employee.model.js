const dbconn = require('../../config/db.config');

const Employee = function (employee) {
    this.first_name = employee.first_name;
    this.last_name = employee.last_name;
    this.email = employee.email;
    this.phone = employee.phone;
    this.organization = employee.organization;
    this.designation = employee.designation;
    this.salary = employee.salary;
    this.created_at = new Date();
    this.updated_at = new Date();
};

Employee.checkEmployeeExist = (email) => {
    return new Promise((resolve, reject) => {
        dbconn.query("SELECT count(id) as total FROM `employees` WHERE `email`=?", [email], (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });

    });
};

Employee.getAllEmployees = () => {
    return new Promise((resolve, reject) => {
        dbconn.query(`SELECT * from employees`, (err, res) => {
            if (err) {
                return reject(err);
            } else {
                return resolve(res);
            }
        })
    })

}

Employee.createNewEmployee = (employeeData) => {
    return new Promise((resolve, reject) => {
        dbconn.query(`INSERT INTO employees SET ?`, employeeData, (err, res) => {
            if (err) {
                return reject(err);
            } else {
                return resolve(res);
            }
        })
    });

};

module.exports = Employee;