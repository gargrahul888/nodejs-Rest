const employeeModel = require('../models/employee.model');

exports.getEmployeeList = async (req, res) => {
    // console.log(req);
    try {
        const results = await employeeModel.getAllEmployees();
        res.status(200).json(
            {
                success: true,
                data: results,
                message: 'Employee List!'
            }
        );
    } catch (error) {
        res.status(500).json(
            {
                success: false,
                data: error
            }
        );
    }
};

exports.createNewEmployee = async (req, res) => {
    try {
        const rows = await employeeModel.checkEmployeeExist(req.body.email);
        var rowstArray = Object.values(JSON.parse(JSON.stringify(rows)));
        if (rowstArray[0].total > 0) {
            return res.status(403).json({ message: 'This email is already registered', success: false });

        }

        const emplyeeReqData = new employeeModel(req.body);
        const result = await employeeModel.createNewEmployee(emplyeeReqData);
        res.status(200).json(
            {
                success: true,
                data: result,
                message: 'Employee added successfully!'
            }
        );
    } catch (error) {
        res.status(500).json(
            {
                success: false,
                data: error
            }
        );
    }

}
